import React, { useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import { Link } from "react-router-dom";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import { StoreIcon } from "@material-ui/icons/";
import { red } from "@material-ui/core/colors";
import { IconButton } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    marginBottom: "50px",
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    textAlign: "left",
  },
  navLink: {
    flexGrow: 1,
    textAlign: "right",
    paddingRight: "10px ",
  },
  mr: {
    marginRight: "10px",
  },
  cart: {
    position: "absolute",
    top: 0,
    right: 20,
    backgroundColor: "red",
    borderRadius: 50,
    fontSize: 16,
    padding: 2,
    zIndex: -1,
  },
}));

function Nav() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <AppBar position="fixed">
        <Toolbar>
          <Link to="/">
            {/* <IconButton edge="start" color="inherit" aria-label="StoreIcon">
              <StoreIcon fontSize="large" />
            </IconButton> */}
          </Link>
          <Typography variant="h6" className={classes.title}>
            Shoe Store
          </Typography>
          {/* <Typography variant="body1" className={classes.navLink}>
            <Link to="/" underline="hover">
              Products
            </Link>
            <Link to="/" underline="hover">
              Contact Us
            </Link>
            <Link to="/" underline="hover">
              About
            </Link>
            <Link to="/cart">
              <IconButton
                edge="end"
                color="inherit"
                aria-label="ShoppingCartIcon"
              >
                <ShoppingCartIcon fontSize="large" />
              </IconButton>
            </Link>
          </Typography> */}
        </Toolbar>
      </AppBar>
    </div>
  );
}

export default Nav;
