import React from "react";

function ProductDetails() {
  return (
    <div>
      <h1>this is from ProductDetails Page</h1>
    </div>
  );
}

export default ProductDetails;
