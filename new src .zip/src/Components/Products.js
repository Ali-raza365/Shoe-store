import React from "react";
import { Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Product from "./Product";

const useStyles = makeStyles({
  root: {
    paddingTop: 100,
    maxWidth: 1200,
    margin: "0 auto",
  },
});

function Products() {
  const classes = useStyles();
  return (
    <div>
      {/* {new Array.entry(32).fill("").map(() => { */}
      return (
      <Grid className={classes.root} container spacing={3}>
        <Product />
        <Product />
        <Product />
        <Product />
      </Grid>
      ); })}
    </div>
  );
}

export default Products;
