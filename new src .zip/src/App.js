import "./App.css";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import Home from "./Components/Home";
import Navbar from "./Components/Navbar";
import Cart from "./Components/Cart";
import ProductDetails from "./Components/ProductDetails";

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/cart" component={Cart} />
          <Route exact path="/products/:id" component={ProductDetails} />
          <Route
            exact
            path="*"
            exact
            component={() => {
              return <h1>page not found</h1>;
            }}
          />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
